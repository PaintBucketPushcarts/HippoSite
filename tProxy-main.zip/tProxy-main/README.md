# tProxy v2
## Whats new in v2?
- New looks  
- Updated links to my pages  
- Stargazers page, free promotion ig  
- You no longer have to provide http or https protocol, It just guesses it so you can just type example.com  
- It now redirects instead of using an iframe, that annoying URL bar was in the way
## Upcoming
- Cloaking  
- Built-in <a href="https://github.com/SevenworksDev/UnblockedHardest">UnblockedHardest</a>  
- Deploy tProxy buttons  
- Better error pages  
- Site compatibility list  
- Use better and faster backend
- Exploits page
- Alert user if tProxy gets blocked after 5 fetch() requests to the main page
## Setup
Use npm to setup tProxy
```
npm i
npm start
```
or use yarn, yarn is better tbh
```
yarn
node .
```
